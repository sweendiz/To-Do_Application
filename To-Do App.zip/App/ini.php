<?php
session.cookie_lifetime = 86400
session.gc_maxlifetime = 200000 